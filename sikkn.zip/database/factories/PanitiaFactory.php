<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Panitia;
use Faker\Generator as Faker;

$factory->define(Panitia::class, function (Faker $faker) {
    return [
        //
    ];
});
