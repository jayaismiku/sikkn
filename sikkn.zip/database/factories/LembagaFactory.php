<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Lembaga;
use Faker\Generator as Faker;

$factory->define(Lembaga::class, function (Faker $faker) {
    return [
        //
    ];
});
