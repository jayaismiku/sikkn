@extends('layouts.dasbor')

@section('title', 'Profile')

@section('content')
<h2>Profile Section</h2>
<hr>
@endsection