@extends('layouts.daftar')

@section('title', 'Pendaftaran')

@section('content')
<div class="col-xl-5 col-lg-5 col-md-7 d-flex flex-column ms-auto me-auto ms-lg-auto me-lg-5">
  <div class="card card-plain">
    <div class="card-header">
      <h4 class="font-weight-bolder">{{ __('Daftar sebagai Mahasiswa') }}</h4>
      <p class="mb-0">{{ __('Silahkan diisi formulir dibawah ini!!') }}</p>
    </div>
    <div class="card-body bg-white">
      <form method="POST" action="{{ route('daftar.mahasiswa.store') }}" enctype="multipart/form-data">
        @csrf
        <!-- Nav tabs -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary active" id="profil-tab" data-bs-toggle="tab" data-bs-target="#profil" type="button" role="tab" aria-controls="profil" aria-selected="false">Profil</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary" id="akademik-tab" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab" aria-controls="akademik" aria-selected="false">Akademik</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary" id="unggah-tab" data-bs-toggle="tab" data-bs-target="#unggah" type="button" role="tab" aria-controls="unggah" aria-selected="false">Unggah</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary" id="other-tab" data-bs-toggle="tab" data-bs-target="#other" type="button" role="tab" aria-controls="other" aria-selected="true">Lainnya</button>
          </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
          <div class="tab-pane mt-2 active" id="profil" role="tabpanel" aria-labelledby="profil-tab" tabindex="0">
            <div class="form-group row my-1">
              <label for="nim" class="col-md-4 col-form-label text-md-right">{{ __('NIM') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('nim') is-invalid @enderror" id="nim" name="nim" value="{{ old('nim') }}" autocomplete="nim" required>
                @error('nim')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="namalengkap" class="col-md-4 col-form-label text-md-right">{{ __('Nama Lengkap') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('namalengkap') is-invalid @enderror" id="namalengkap" name="namalengkap" value="{{ old('namalengkap') }}" autocomplete="namalengkap" required>
                @error('namalengkap')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="jenis_kelamin" class="col-md-4 col-form-label text-md-right">{{ __('Jenis Kelamin') }}</label>
              <div class="col-md-6">
                <select class="form-select form-control @error('jenis_kelamin') is-invalid @enderror" id="jenis_kelamin" name="jenis_kelamin" aria-label="select jenis_kelamin" required>
                  <option selected>- Pilih Jenis Kelamin -</option>
                  <option value="L">{{ __('Laki-laki') }}</option>
                  <option value="P">{{ __('Perempuan') }}</option>
                </select>
                @error('jenis_kelamin')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="alamat" class="col-md-4 col-form-label text-md-right">{{ __('Alamat') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('alamat') is-invalid @enderror" id="alamat" name="alamat" value="{{ old('alamat') }}" autocomplete="alamat">
                @error('alamat')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="telp" class="col-md-4 col-form-label text-md-right">{{ __('No Whatsapp (aktif)') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('telp') is-invalid @enderror" id="telp" name="telp" value="{{ old('telp') }}" autocomplete="telp" required>
                @error('telp')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail') }}</label>
              <div class="col-md-6">
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" autocomplete="email" required>
                @error('email')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>
              <div class="col-md-6">
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" autocomplete="new-password" required>
                @error('password')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="password_confirmation" class="col-md-4 col-form-label text-md-right">{{ __('Konfirmasi Password') }}</label>
              <div class="col-md-6">
                <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" autocomplete="password_confirmation" required>
                @error('password_confirmations')
                  <span id="fb_password_confirmation" class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
          </div>
          <div class="tab-pane mt-2" id="akademik" role="tabpanel" aria-labelledby="akademik-tab" tabindex="0">
            <div class="form-group row my-1">
              <label for="fakultas" class="col-md-4 col-form-label text-md-right">{{ __('Fakultas') }}</label>
              <div class="col-md-6">
                <select class="form-select form-control @error('fakultas') is-invalid @enderror" id="fakultas" name="fakultas" aria-label="select fakultas" required>
                  <option selected>- Pilih Fakultas -</option>
                  @foreach($fakultas as $fk)
                  <option value="{{ $fk->kode_fakultas }}">{{ $fk->nama_fakultas }}</option>
                  @endforeach
                </select>
                @error('fakultas')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="prodi" class="col-md-4 col-form-label text-md-right">{{ __('Program Studi') }}</label>
              <div class="col-md-6">
                <select class="form-select form-control @error('prodi') is-invalid @enderror" id="prodi" name="prodi" aria-label="select prodi" required>
                  <option selected>- Pilih Program Studi -</option>
                  @foreach($prodi as $pr)
                  <option value="{{ $pr->kode_prodi }}">{{ $pr->nama_prodi }}</option>
                  @endforeach
                </select>
                @error('prodi')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="semester" class="col-md-4 col-form-label text-md-right">{{ __('semester') }}</label>
              <div class="col-md-6">
                <select class="form-select form-control @error('semester') is-invalid @enderror" id="semester" name="semester" aria-label="select semester" required>
                  <option selected>- Pilih Semester -</option>
                  <option value="4">4</option>
                  <option value="6">6</option>
                  <option value="8">8</option>
                </select>
                @error('semester')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="jenis_kkn" class="col-md-4 col-form-label text-md-right">{{ __('Jenis KKN') }}</label>
              <div class="col-md-6">
                <select class="form-select form-control @error('jenis_kkn') is-invalid @enderror" id="jenis_kkn" name="jenis_kkn" aria-label="select jenis kkn" required>
                  <option selected>- Pilih Jenis KKN -</option>
                  <option value="Reguler">{{ __('Reguler') }}</option>
                  <option value="nonreguler">{{ __('Non Reguler') }}</option>
                  <option value="tematik">{{ __('Tematik') }}</option>
                </select>
                @error('jenis_kkn')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
          </div>
          <div class="tab-pane mt-2" id="unggah" role="tabpanel" aria-labelledby="unggah-tab" tabindex="0">
            <div class="form-group row my-1">
              <label for="unggahkrs" class="col-md-4 col-form-label text-md-right">{{ __('Unggah KRS') }}</label>
              <div class="col-md-6">
                <input type="file" class="form-control @error('unggahkrs') is-invalid @enderror" id="unggahkrs" name="unggahkrs" value="{{ old('unggahkrs') }}" autocomplete="unggahkrs" accept="image/*" required>
                @error('unggahkrs')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="unggahukt" class="col-md-4 col-form-label text-md-right">{{ __('Unggah UKT') }}</label>
              <div class="col-md-6">
                <input type="file" class="form-control @error('unggahukt') is-invalid @enderror" id="unggahukt" name="unggahukt" value="{{ old('unggahukt') }}" autocomplete="unggahukt" accept="image/*" required>
                @error('unggahukt')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="unggahbiaya" class="col-md-4 col-form-label text-md-right">{{ __('Unggah Biaya KKN') }}</label>
              <div class="col-md-6">
                <input type="file" class="form-control @error('unggahbiaya') is-invalid @enderror" id="unggahbiaya" name="unggahbiaya" value="{{ old('unggahbiaya') }}" autocomplete="unggahbiaya" accept="image/*" required>
                @error('unggahbiaya')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="suratkesediaan" class="col-md-4 col-form-label text-md-right">{{ __('Surat Kesediaan Peserta KKN') }}</label>
              <div class="col-md-6">
                <input type="file" class="form-control @error('suratkesediaan') is-invalid @enderror" id="suratkesediaan" name="suratkesediaan" value="{{ old('suratkesediaan') }}" autocomplete="suratkesediaan" accept="image/*" required>
                @error('suratkesediaan')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="suratijinortu" class="col-md-4 col-form-label text-md-right">{{ __('Surat Ijin Orang Tua/Wali') }}</label>
              <div class="col-md-6">
                <input type="file" class="form-control @error('suratijinortu') is-invalid @enderror" id="suratijinortu" name="suratijinortu" value="{{ old('suratijinortu') }}" autocomplete="suratijinortu" accept="image/*" required>
                @error('suratijinortu')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
          </div>
          <div class="tab-pane mt-2" id="other" role="tabpanel" aria-labelledby="other-tab" tabindex="0">
          <div class="form-group row my-1">
              <label for="unggahsuratsakit" class="col-md-4 col-form-label text-md-right">{{ __('Unggah Surat Sakit Berat (dari Dokter)') }}</label>
              <div class="col-md-6">
                <input type="file" class="form-control @error('unggahsuratsakit') is-invalid @enderror" id="unggahsuratsakit" name="unggahsuratsakit" value="{{ old('unggahsuratsakit') }}" autocomplete="unggahsuratsakit" accept="image/*">
                @error('unggahsuratsakit')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="alergi" class="col-md-4 col-form-label text-md-right">{{ __('Alergi') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('alergi') is-invalid @enderror" id="alergi" name="alergi" value="{{ old('alergi') }}" autocomplete="alergi">
                @error('alergi')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="nama_ortu" class="col-md-4 col-form-label text-md-right">{{ __('Nama Orang Tua/Wali') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('nama_ortu') is-invalid @enderror" id="nama_ortu" name="nama_ortu" value="{{ old('nama_ortu') }}" autocomplete="nama_ortu">
                @error('nama_ortu')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="telp_ortu" class="col-md-4 col-form-label text-md-right">{{ __('No.Telp Orang Tua/Wali') }}</label>
              <div class="col-md-6">
                <input type="text" class="form-control @error('telp_ortu') is-invalid @enderror" id="telp_ortu" name="telp_ortu" value="{{ old('telp_ortu') }}" autocomplete="telp_ortu">
                @error('telp_ortu')
                  <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>
            </div>

          </div>
        </div>
        
        <div class="form-group row mb-0 mt-4">
          <div class="col-md-6 d-flex justify-content-center links">
            <input type="hidden" name="role" value="mahasiswa">
            <input type="hidden" name="username" id="username" value="" />
            <button type="submit" class="btn btn-info">
              <span class="material-icons">inventory</span> 
              {{ __('Daftar KKN') }}
            </button>
          </div>
          <div class="col-md-6 justify-content-center links fs-6">
            <span>{{ __('Sudah punya akun?') }}</span><br/>
            <a href="{{ route('login') }}" class="ml-2 text-info"><span>{{ __('Masuk') }}</span></a>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>

<script type="text/javascript">
  function generateRandomString(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  $(document).ready(function(){
    $('#namalengkap').change(function(event) {
      let nama = $(this).val();
      nama_depan = nama.split(' ')[0].toLowerCase();
      username = nama_depan + '-' + generateRandomString(5);
      console.log(username);
      $('#username').val(username);
    });

    $('#telp').change(function(){
      let telp = '62';
      let angka1 = $(this).val().substring(0,1);
      let angka2 = $(this).val().substring(1);
      if(angka1 == 0){
        telp = telp + angka2;
      }else{
        telp = angka1 + angka2;
      }
      $(this).val(telp);
      console.log(telp);
    });

    $('#telp_ortu').change(function(){
      let telp = '62';
      let angka1 = $(this).val().substring(0,1);
      let angka2 = $(this).val().substring(1);
      if(angka1 == 0){
        telp = telp + angka2;
      }else{
        telp = angka1 + angka2;
      }
      $(this).val(telp);
      console.log(telp);
    });

   $('#password_confirmation').change(function(){
      let pass1 = $('#password').val();
      let pass2 = $(this).val();
      if(pass2 !== pass1){
        console.log('password tidak sama');
        $(this).addClass('is-invalid');
        $('#fb_password_confirmation').show().text('password tidak sama');
      }
    });

  });
</script>
@endsection