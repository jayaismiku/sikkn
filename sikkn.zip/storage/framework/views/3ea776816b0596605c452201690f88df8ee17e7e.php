

<?php $__env->startSection('title', 'Edit Prodi'); ?>

<?php $__env->startSection('pathway'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item text-sm">
      <a class="opacity-3 text-dark" href="<?php echo e(route('home')); ?>">
        <span class="material-icons">cottage</span>
      </a>
    </li>
    <li class="breadcrumb-item text-sm">
      <a class="opacity-5 text-dark" href="<?php echo e(route('desa.index')); ?>"><?php echo e(__('Desa')); ?></a>
    </li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">
      <span><?php echo e(__('Ubah Desa')); ?></span>
    </li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-12">
    <div class="card my-4">
      <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-secondary shadow-secondary border-radius-lg pt-4 pb-3">
          <h6 class="text-white text-capitalize ps-3">Ubah Data Desa</h6>
        </div>
      </div>
      <div class="card-body px-0 pb-2 mx-3 ">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <br />
        <?php endif; ?>
        <form id="editDesa" method="post" action="<?php echo e(route('desa.update', $desa->desa_id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class=" input-group-outline my-3">
              <label class="form-label" for="nama_desa"><?php echo e(__('Nama Desa:')); ?></label>
              <input type="text" class="form-control px-2 py-2" name="nama_desa" value="<?php echo e($desa->nama_desa); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
              <label class="form-label" for="alamat"><?php echo e(__('Alamat:')); ?></label>
              <input type="text" class="form-control px-2 py-2" name="alamat" value="<?php echo e($desa->alamat); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
              <label class="form-label" for="longitude"><?php echo e(__('Longitude')); ?></label>
              <input type="text" id="long" class="form-control px-2 py-2" name="longitude" value="<?php echo e($desa->longitude); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
              <label class="form-label" for="latitude"><?php echo e(__('Latitude')); ?></label>
              <input type="text" id="lat" class="form-control px-2 py-2" name="latitude" value="<?php echo e($desa->latitude); ?>" required/>
          </div>
          <div class="form-group mt-4">
            <input type="hidden" class="form-control px-2 py-2" name="desa_id" value="<?php echo e($desa->desa_id); ?>" />
            <a class="btn btn-warning xs" onclick="getLocation()">
              <span class="material-icons">pin_drop</span>
            </a>
            <button type="submit" class="btn btn-success xs">
              <span class="material-icons">save</span>
            </button>
            <a class="btn btn-info xs" href="<?php echo e(route('desa.index')); ?>">
              <span class="material-icons">undo</span>
            </a>
          </div>         
        </form>
      </div>
    </div>
  </div>
</div>
<script>
var long = document.getElementById("long");
var lat = document.getElementById("lat");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
    console.log(navigator.geolocation.getCurrentPosition(showPosition));
  } else { 
    alert("Geolocation is not supported by this browser.");
  }
}

function showPosition(position) {
  document.getElementById("long").value = position.coords.longitude;
  document.getElementById("lat").value = position.coords.latitude;
}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/desa/edit.blade.php ENDPATH**/ ?>