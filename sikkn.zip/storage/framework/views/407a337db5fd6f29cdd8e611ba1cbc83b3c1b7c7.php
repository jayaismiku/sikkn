

<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-5 col-lg-5 col-md-7 d-flex flex-column ms-auto me-auto ms-lg-auto me-lg-5">
  <div class="card card-plain">
    <div class="card-header">
      <h4 class="font-weight-bolder"><?php echo e(__('Daftar sebagai Mahasiswa')); ?></h4>
      <p class="mb-0"><?php echo e(__('Silahkan diisi formulir dibawah ini!!')); ?></p>
    </div>
    <div class="card-body bg-white">
      <form method="POST" action="<?php echo e(route('daftar.mahasiswa.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary active" id="profil-tab" data-bs-toggle="tab" data-bs-target="#profil" type="button" role="tab" aria-controls="profil" aria-selected="false">Profil</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary" id="akademik-tab" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab" aria-controls="akademik" aria-selected="false">Akademik</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary" id="unggah-tab" data-bs-toggle="tab" data-bs-target="#unggah" type="button" role="tab" aria-controls="unggah" aria-selected="false">Unggah</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link text-secondary" id="other-tab" data-bs-toggle="tab" data-bs-target="#other" type="button" role="tab" aria-controls="other" aria-selected="true">Lainnya</button>
          </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
          <div class="tab-pane mt-2 active" id="profil" role="tabpanel" aria-labelledby="profil-tab" tabindex="0">
            <div class="form-group row my-1">
              <label for="nim" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NIM')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nim" name="nim" value="<?php echo e(old('nim')); ?>" autocomplete="nim" required>
                <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="namalengkap" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Lengkap')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['namalengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="namalengkap" name="namalengkap" value="<?php echo e(old('namalengkap')); ?>" autocomplete="namalengkap" required>
                <?php $__errorArgs = ['namalengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="jenis_kelamin" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jenis Kelamin')); ?></label>
              <div class="col-md-6">
                <select class="form-select form-control <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenis_kelamin" name="jenis_kelamin" aria-label="select jenis_kelamin" required>
                  <option selected>- Pilih Jenis Kelamin -</option>
                  <option value="L"><?php echo e(__('Laki-laki')); ?></option>
                  <option value="P"><?php echo e(__('Perempuan')); ?></option>
                </select>
                <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="alamat" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Alamat')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat" name="alamat" value="<?php echo e(old('alamat')); ?>" autocomplete="alamat">
                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="telp" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No Whatsapp (aktif)')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="telp" name="telp" value="<?php echo e(old('telp')); ?>" autocomplete="telp" required>
                <?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>
              <div class="col-md-6">
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
              <div class="col-md-6">
                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="new-password" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="password_confirmation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Konfirmasi Password')); ?></label>
              <div class="col-md-6">
                <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" autocomplete="password_confirmation" required>
                <?php $__errorArgs = ['password_confirmations'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span id="fb_password_confirmation" class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="tab-pane mt-2" id="akademik" role="tabpanel" aria-labelledby="akademik-tab" tabindex="0">
            <div class="form-group row my-1">
              <label for="fakultas" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fakultas')); ?></label>
              <div class="col-md-6">
                <select class="form-select form-control <?php $__errorArgs = ['fakultas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="fakultas" name="fakultas" aria-label="select fakultas" required>
                  <option selected>- Pilih Fakultas -</option>
                  <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($fk->kode_fakultas); ?>"><?php echo e($fk->nama_fakultas); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['fakultas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="prodi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Program Studi')); ?></label>
              <div class="col-md-6">
                <select class="form-select form-control <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prodi" name="prodi" aria-label="select prodi" required>
                  <option selected>- Pilih Program Studi -</option>
                  <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($pr->kode_prodi); ?>"><?php echo e($pr->nama_prodi); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['prodi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="semester" class="col-md-4 col-form-label text-md-right"><?php echo e(__('semester')); ?></label>
              <div class="col-md-6">
                <select class="form-select form-control <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="semester" name="semester" aria-label="select semester" required>
                  <option selected>- Pilih Semester -</option>
                  <option value="4">4</option>
                  <option value="6">6</option>
                  <option value="8">8</option>
                </select>
                <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="jenis_kkn" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Jenis KKN')); ?></label>
              <div class="col-md-6">
                <select class="form-select form-control <?php $__errorArgs = ['jenis_kkn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenis_kkn" name="jenis_kkn" aria-label="select jenis kkn" required>
                  <option selected>- Pilih Jenis KKN -</option>
                  <option value="Reguler"><?php echo e(__('Reguler')); ?></option>
                  <option value="nonreguler"><?php echo e(__('Non Reguler')); ?></option>
                  <option value="tematik"><?php echo e(__('Tematik')); ?></option>
                </select>
                <?php $__errorArgs = ['jenis_kkn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="tab-pane mt-2" id="unggah" role="tabpanel" aria-labelledby="unggah-tab" tabindex="0">
            <div class="form-group row my-1">
              <label for="unggahkrs" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unggah KRS')); ?></label>
              <div class="col-md-6">
                <input type="file" class="form-control <?php $__errorArgs = ['unggahkrs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="unggahkrs" name="unggahkrs" value="<?php echo e(old('unggahkrs')); ?>" autocomplete="unggahkrs" accept="image/*" required>
                <?php $__errorArgs = ['unggahkrs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="unggahukt" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unggah UKT')); ?></label>
              <div class="col-md-6">
                <input type="file" class="form-control <?php $__errorArgs = ['unggahukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="unggahukt" name="unggahukt" value="<?php echo e(old('unggahukt')); ?>" autocomplete="unggahukt" accept="image/*" required>
                <?php $__errorArgs = ['unggahukt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="unggahbiaya" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unggah Biaya KKN')); ?></label>
              <div class="col-md-6">
                <input type="file" class="form-control <?php $__errorArgs = ['unggahbiaya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="unggahbiaya" name="unggahbiaya" value="<?php echo e(old('unggahbiaya')); ?>" autocomplete="unggahbiaya" accept="image/*" required>
                <?php $__errorArgs = ['unggahbiaya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="suratkesediaan" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Surat Kesediaan Peserta KKN')); ?></label>
              <div class="col-md-6">
                <input type="file" class="form-control <?php $__errorArgs = ['suratkesediaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="suratkesediaan" name="suratkesediaan" value="<?php echo e(old('suratkesediaan')); ?>" autocomplete="suratkesediaan" accept="image/*" required>
                <?php $__errorArgs = ['suratkesediaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="suratijinortu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Surat Ijin Orang Tua/Wali')); ?></label>
              <div class="col-md-6">
                <input type="file" class="form-control <?php $__errorArgs = ['suratijinortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="suratijinortu" name="suratijinortu" value="<?php echo e(old('suratijinortu')); ?>" autocomplete="suratijinortu" accept="image/*" required>
                <?php $__errorArgs = ['suratijinortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="tab-pane mt-2" id="other" role="tabpanel" aria-labelledby="other-tab" tabindex="0">
          <div class="form-group row my-1">
              <label for="unggahsuratsakit" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Unggah Surat Sakit Berat (dari Dokter)')); ?></label>
              <div class="col-md-6">
                <input type="file" class="form-control <?php $__errorArgs = ['unggahsuratsakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="unggahsuratsakit" name="unggahsuratsakit" value="<?php echo e(old('unggahsuratsakit')); ?>" autocomplete="unggahsuratsakit" accept="image/*">
                <?php $__errorArgs = ['unggahsuratsakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="alergi" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Alergi')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['alergi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alergi" name="alergi" value="<?php echo e(old('alergi')); ?>" autocomplete="alergi">
                <?php $__errorArgs = ['alergi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="nama_ortu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Orang Tua/Wali')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['nama_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_ortu" name="nama_ortu" value="<?php echo e(old('nama_ortu')); ?>" autocomplete="nama_ortu">
                <?php $__errorArgs = ['nama_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row my-1">
              <label for="telp_ortu" class="col-md-4 col-form-label text-md-right"><?php echo e(__('No.Telp Orang Tua/Wali')); ?></label>
              <div class="col-md-6">
                <input type="text" class="form-control <?php $__errorArgs = ['telp_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="telp_ortu" name="telp_ortu" value="<?php echo e(old('telp_ortu')); ?>" autocomplete="telp_ortu">
                <?php $__errorArgs = ['telp_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

          </div>
        </div>
        
        <div class="form-group row mb-0 mt-4">
          <div class="col-md-6 d-flex justify-content-center links">
            <input type="hidden" name="role" value="mahasiswa">
            <input type="hidden" name="username" id="username" value="" />
            <button type="submit" class="btn btn-info">
              <span class="material-icons">inventory</span> 
              <?php echo e(__('Daftar KKN')); ?>

            </button>
          </div>
          <div class="col-md-6 justify-content-center links fs-6">
            <span><?php echo e(__('Sudah punya akun?')); ?></span><br/>
            <a href="<?php echo e(route('login')); ?>" class="ml-2 text-info"><span><?php echo e(__('Masuk')); ?></span></a>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>

<script type="text/javascript">
  function generateRandomString(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  $(document).ready(function(){
    $('#namalengkap').change(function(event) {
      let nama = $(this).val();
      nama_depan = nama.split(' ')[0].toLowerCase();
      username = nama_depan + '-' + generateRandomString(5);
      console.log(username);
      $('#username').val(username);
    });

    $('#telp').change(function(){
      let telp = '62';
      let angka1 = $(this).val().substring(0,1);
      let angka2 = $(this).val().substring(1);
      if(angka1 == 0){
        telp = telp + angka2;
      }else{
        telp = angka1 + angka2;
      }
      $(this).val(telp);
      console.log(telp);
    });

    $('#telp_ortu').change(function(){
      let telp = '62';
      let angka1 = $(this).val().substring(0,1);
      let angka2 = $(this).val().substring(1);
      if(angka1 == 0){
        telp = telp + angka2;
      }else{
        telp = angka1 + angka2;
      }
      $(this).val(telp);
      console.log(telp);
    });

   $('#password_confirmation').change(function(){
      let pass1 = $('#password').val();
      let pass2 = $(this).val();
      if(pass2 !== pass1){
        console.log('password tidak sama');
        $(this).addClass('is-invalid');
        $('#fb_password_confirmation').show().text('password tidak sama');
      }
    });

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.daftar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/pendaftaran/mahasiswa.blade.php ENDPATH**/ ?>