

<?php $__env->startSection('title', 'Edit Dosen'); ?>

<?php $__env->startSection('pathway'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item text-sm">
      <a class="opacity-3 text-dark" href="<?php echo e(route('home')); ?>">
        <span class="material-icons">cottage</span>
      </a>
    </li>
    <li class="breadcrumb-item text-sm">
      <a class="opacity-5 text-dark" href="<?php echo e(route('dosen')); ?>">Dosen</a>
    </li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">
      <span>Edit Dosen</span>
    </li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-12">
    <div class="card my-4">
      <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-secondary shadow-secondary border-radius-lg pt-4 pb-3">
          <h6 class="text-white text-capitalize ps-3"><?php echo e(__('Ubah Data Dosen')); ?></h6>
        </div>
      </div>
      <div class="card-body px-0 pb-2 mx-3 ">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <br />
        <?php endif; ?>
        <form id="editDosen" method="post" action="<?php echo e(route('updateDosen', $dosen->dosen_id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="nidn"><?php echo e(__('NIDN:')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="nidn" value="<?php echo e($dosen->nidn); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="nip"><?php echo e(__('NIP:')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="nip" value="<?php echo e($dosen->nip); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="nama_lengkap"><?php echo e(__('Nama Lengkap (tanpa gelar):')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="nama_lengkap" value="<?php echo e($dosen->nama_lengkap); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="gelar_depan"><?php echo e(__('Gelar Depan')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="gelar_depan" value="<?php echo e($dosen->gelar_depan); ?>"/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="gelar_belakang"><?php echo e(__('Gelar Belakang')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="gelar_belakang" value="<?php echo e($dosen->gelar_belakang); ?>"/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="pangkat"><?php echo e(__('Pangkat')); ?></label>
            <select class="form-control form-select px-2" aria-label=".form-select-sm select-pangkat" name="pangkat">
              <option value="Penata Muda" <?php echo e($dosen->pangkat=='Penata Muda'?'selected':''); ?>><?php echo e(__('Penata Muda')); ?></option>
              <option value="Penata Muda Tk.I" <?php echo e($dosen->pangkat=='Penata Muda Tk.I'?'selected':''); ?>><?php echo e(__('Penata Muda Tk.I')); ?></option>
              <option value="Penata" <?php echo e($dosen->pangkat=='Penata'?'selected':''); ?>><?php echo e(__('Penata')); ?></option>
              <option value="Penata Tk.I" <?php echo e($dosen->pangkat=='Penata Tk.I'?'selected':''); ?>><?php echo e(__('Penata Tk.I')); ?></option>
              <option value="Pembina" <?php echo e($dosen->pangkat=='Pembina'?'selected':''); ?>><?php echo e(__('Pembina')); ?></option>
              <option value="Pembina Tk.I" <?php echo e($dosen->pangkat=='Pembina Tk.I'?'selected':''); ?>><?php echo e(__('Pembina Tk.I')); ?></option>
              <option value="Pembina Utama Muda" <?php echo e($dosen->pangkat=='Pembina Utama Muda'?'selected':''); ?>><?php echo e(__('Pembina Utama Muda')); ?></option>
              <option value="Pembina Utama Madya" <?php echo e($dosen->pangkat=='Pembina Utama Madya'?'selected':''); ?>><?php echo e(__('Pembina Utama Madya')); ?></option>
              <option value="Pembina Utama" <?php echo e($dosen->pangkat=='Pembina Utama'?'selected':''); ?>><?php echo e(__('Pembina Utama')); ?></option>
            </select>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="golongan"><?php echo e(__('Golongan')); ?></label>
            <select class="form-control form-select px-2" aria-label=".form-select-sm select-golongan" name="golongan" required>
              <option value="Gol. III/a" <?php echo e($dosen->golongan=='Gol. III/a'?'selected':''); ?>><?php echo e(__('Gol. III/a')); ?></option>
              <option value="Gol. III/b" <?php echo e($dosen->golongan=='Gol. III/b'?'selected':''); ?>><?php echo e(__('Gol. III/b')); ?></option>
              <option value="Gol. III/c" <?php echo e($dosen->golongan=='Gol. III/c'?'selected':''); ?>><?php echo e(__('Gol. III/c')); ?></option>
              <option value="Gol. III/d" <?php echo e($dosen->golongan=='Gol. III/d'?'selected':''); ?>><?php echo e(__('Gol. III/d')); ?></option>
              <option value="Gol. IV/a" <?php echo e($dosen->golongan=='Gol. IV/a'?'selected':''); ?>><?php echo e(__('Gol. IV/a')); ?></option>
              <option value="Gol. IV/b" <?php echo e($dosen->golongan=='Gol. IV/b'?'selected':''); ?>><?php echo e(__('Gol. IV/b')); ?></option>
              <option value="Gol. IV/c" <?php echo e($dosen->golongan=='Gol. IV/c'?'selected':''); ?>><?php echo e(__('Gol. IV/c')); ?></option>
              <option value="Gol. IV/d" <?php echo e($dosen->golongan=='Gol. IV/d'?'selected':''); ?>><?php echo e(__('Gol. IV/d')); ?></option>
              <option value="Gol. IV/e" <?php echo e($dosen->golongan=='Gol. IV/e'?'selected':''); ?>><?php echo e(__('Gol. IV/e')); ?></option>
            </select>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="fakultas"><?php echo e(__('Fakultas')); ?></label>
            <select class="form-control form-select px-2" aria-label=".form-select-sm select-fakultas" name="fakultas" required>
              <option value="FST" <?php echo e($dosen->fakultas=='FST'?'selected':''); ?>><?php echo e(__('Fakultas Sains dan Teknologi')); ?></option>
              <option value="FSH" <?php echo e($dosen->fakultas=='FSH'?'selected':''); ?>><?php echo e(__('Fakultas Sosial Humaniora')); ?></option>
              <option value="FEB" <?php echo e($dosen->fakultas=='FEB'?'selected':''); ?>><?php echo e(__('Fakultas Ekonomi dan Bisnis')); ?></option>
              <option value="FAI" <?php echo e($dosen->fakultas=='FAI'?'selected':''); ?>><?php echo e(__('Fakultas Agama Islam')); ?></option>
            </select>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="prodi"><?php echo e(__('Program Studi')); ?></label>
            <select class="form-control form-select px-2" aria-label=".form-select-sm select-prodi" name="prodi" required>
              <option value="TE" <?php echo e($dosen->prodi=='TE'?'selected':''); ?>><?php echo e(__('Teknik Elektro')); ?></option>
              <option value="IF" <?php echo e($dosen->prodi=='IF'?'selected':''); ?>><?php echo e(__('Teknik Informatika')); ?></option>
              <option value="TI" <?php echo e($dosen->prodi=='TI'?'selected':''); ?>><?php echo e(__('Teknik Industri')); ?></option>
              <option value="TP" <?php echo e($dosen->prodi=='TP'?'selected':''); ?>><?php echo e(__('Teknologi Pangan')); ?></option>
              <option value="BIO" <?php echo e($dosen->prodi=='BIO'?'selected':''); ?>><?php echo e(__('Bioteknologi')); ?></option>
              <option value="FA" <?php echo e($dosen->prodi=='FA'?'selected':''); ?>><?php echo e(__('Farmasi')); ?></option>
              <option value="AGRI" <?php echo e($dosen->prodi=='AGRI'?'selected':''); ?>><?php echo e(__('Agribisnis')); ?></option>
              <option value="ILKOM" <?php echo e($dosen->prodi=='ILKOM'?'selected':''); ?>><?php echo e(__('Ilmu Komunikasi')); ?></option>
              <option value="PSI" <?php echo e($dosen->prodi=='PSI'?'selected':''); ?>><?php echo e(__('Psikologi')); ?></option>
              <option value="KTF" <?php echo e($dosen->prodi=='KTF'?'selected':''); ?>><?php echo e(__('Kriya Tekstil dan Fashion')); ?></option>
              <option value="AP" <?php echo e($dosen->prodi=='AP'?'selected':''); ?>><?php echo e(__('Administrasi Publik')); ?></option>
              <option value="AK" <?php echo e($dosen->prodi=='AK'?'selected':''); ?>><?php echo e(__('Akuntansi')); ?></option>
              <option value="MAN" <?php echo e($dosen->prodi=='MAN'?'selected':''); ?>><?php echo e(__('Manajemen')); ?></option>
              <option value="PAI" <?php echo e($dosen->prodi=='PAI'?'selected':''); ?>><?php echo e(__('Pendidikan Agama Islam')); ?></option>
              <option value="PIAUD" <?php echo e($dosen->prodi=='PIAUD'?'selected':''); ?>><?php echo e(__('Pendidikan Islam Anak Usia Dini')); ?></option>
              <option value="HKI" <?php echo e($dosen->prodi=='HKI'?'selected':''); ?>><?php echo e(__('Hukum Keluarga Islam')); ?></option>
              <option value="KPI" <?php echo e($dosen->prodi=='KPI'?'selected':''); ?>><?php echo e(__('Komunikasi Penyiaran Islam')); ?></option>
              <option value="EKSYAR" <?php echo e($dosen->prodi=='EKSYAR'?'selected':''); ?>><?php echo e(__('Ekonomi Syariah')); ?></option>
            </select>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="telp"><?php echo e(__('Telp (WA)')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="telp" value="<?php echo e($dosen->telp); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="alamat"><?php echo e(__('Alamat')); ?></label>
            <input type="text" class="form-control px-2 py-2" name="alamat" value="<?php echo e($dosen->alamat); ?>" required/>
          </div>
          <div class="form-group">
            <input type="hidden" class="form-control px-2 py-2" name="dosen_id" value="<?php echo e($dosen->dosen_id); ?>" />
            <button type="submit" class="btn btn-success xs">
              <span class="material-icons">save</span>
            </button>
            <a class="btn btn-info xs" href="<?php echo e(route('prodi')); ?>">
              <span class="material-icons">undo</span>
            </a>
          </div>         
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/dosen/edit.blade.php ENDPATH**/ ?>