

<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-5 col-lg-5 col-md-7 d-flex flex-column ms-auto me-auto ms-lg-auto me-lg-5">
  <div class="card card-plain">
    <div class="card-header">
      <h4 class="font-weight-bolder"><?php echo e(__('Perhatian !!!')); ?></h4>
      <p class="mb-0"><?php echo e(__('This Page is Underconstruction')); ?></p>
    </div>
    <div class="card-body bg-white">
      <p><img class="img" src="<?php echo e(asset('icons/work-in-progress.png')); ?>" alt="Image Underconstruction"></p>
      <p><a class="btn btn-lg btn-secondary" href="<?php echo e(route('login')); ?>">Kembali Login</a></p>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.daftar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/pendaftaran/underconstruction.blade.php ENDPATH**/ ?>