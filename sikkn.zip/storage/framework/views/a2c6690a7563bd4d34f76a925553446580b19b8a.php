

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="fw-light">Dashboard <?php echo e(Auth::user()->role); ?></h2>
<h5 class="fst-italic">Welcome <?php echo e(Auth::user()->username); ?> , Love to see you back.</h5>
<hr>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dasbor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/mahasiswa.blade.php ENDPATH**/ ?>