<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
<h2>Profile Section</h2>


<?php echo $__env->make('layouts.dasbor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\resources\views/profile.blade.php ENDPATH**/ ?>