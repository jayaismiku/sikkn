<?php $__env->startSection('title', 'Auth Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header"><?php echo e(__('Login')); ?></div>

				<div class="card-body">
					<form method="POST" action="<?php echo e(route('login')); ?>">
						<?php echo csrf_field(); ?>

						<div class="form-group row">
							<label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>
							<div class="col-md-6">
								<input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
								<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>

						<div class="form-group row">
							<label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
							<div class="col-md-6">
								<input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
								<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>

						<div class="form-group row">
							<div class="col-md-6 offset-md-4">
								<div class="form-check">
									<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
									<label class="form-check-label" for="remember">
										<?php echo e(__('Remember Me')); ?>

									</label>
								</div>
							</div>
						</div>

						<div class="form-group row mb-0">
							<div class="col-md-8 offset-md-4">
								<button type="submit" class="btn btn-primary">
									<?php echo e(__('Login')); ?>

								</button>

								<?php if(Route::has('password.request')): ?>
									<a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
										<?php echo e(__('Forgot Your Password?')); ?>

									</a>
								<?php endif; ?>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form-auth'); ?>
<?php if(session()->get('error')): ?>
<div id="alertSuccess" class="alert alert-success alert-dismissible text-white fade show mx-3" role="alert">
	<span class="alert-icon align-middle">
		<span class="material-icons text-md">thumb_up_off_alt</span>
	</span>
	<span class="alert-text"><strong>Success!</strong> <?php echo e(session()->get('error')); ?></span>
	<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
		<span aria-hidden="true">&times;</span>
	</button>
</div>
<?php endif; ?>
<form method="POST" action="<?php echo e(route('login')); ?>">
	<?php echo csrf_field(); ?>
	<div class="input-group mb-3">
		<div class="input-group-append">
			<span class="input-group-text"><i class="fas fa-at"></i></span>
		</div>
		<input type="text" id="email" name="email" class="form-control input_user <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" placeholder="username" required autocomplete="email" autofocus>
		<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong><?php echo e($message); ?></strong>
			</span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="input-group mb-2">
		<div class="input-group-append">
			<span class="input-group-text"><i class="fas fa-key"></i></span>
		</div>
		<input id="password" type="password" name="password" class="form-control input_pass <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="" placeholder="password" required autocomplete="current-password">
		<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong><?php echo e($message); ?></strong>
			</span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="form-group">
		<div class="custom-control custom-checkbox">
			<input type="checkbox" class="custom-control-input" id="customControlInline">
			<label class="custom-control-label" for="customControlInline"><?php echo e(__('Ingatkan Saya')); ?></label>
		</div>
	</div>
	<div class="d-flex justify-content-center mt-3 login_container">
		<div class="d-flex justify-content-center links mx-2">
			<button type="submit" name="button" class="btn btn-info login_btn"><i class="fa-solid fa-floppy-disk text-lg"></i> <?php echo e(__('Masuk')); ?></button>
		</div>
		<div class="d-flex justify-content-center links mx-2">
			<a href="<?php echo e(route('daftar')); ?>" class="btn btn-warning ml-2"><i class="fa-solid fa-user-plus text-lg"></i> <?php echo e(__('Buat Akun')); ?></a>
		</div>
	</div>
</form>
</div>
<div class="mb-2">
	<div class="d-flex justify-content-center links">
		<a href="<?php echo e(route('password.request')); ?>"><i class="fa-solid fa-circle-question text-lg"></i> <?php echo e(__('Lupa kata sandi?')); ?></a>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/auth/login.blade.php ENDPATH**/ ?>