

<?php $__env->startSection('title', 'Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xl-5 col-lg-5 col-md-7 d-flex flex-column ms-auto me-auto ms-lg-auto me-lg-5">
  <div class="card card-plain">
    <div class="card-header text-center">
      <h4 class="font-weight-bolder"><?php echo e(__('Mau Daftar Sebagai?')); ?></h4>
      <p class="mb-0"><?php echo e(__('Pilih Mode Pengguna')); ?></p>
    </div>
    <div class="card-body bg-white">
      <a class="btn btn-lg btn-icon btn-3 btn-info w-100" href="<?php echo e(Route('daftar.panitia')); ?>">
        <span class="btn-inner--icon"><i class="material-icons">supervisor_account</i></span><br>
        <span class="btn-inner--text"><?php echo e(__('Panitia KKN')); ?></span>
      </a>
      <a class="btn btn-lg btn-icon btn-3 btn-warning w-100" href="<?php echo e(Route('daftar.pemonev')); ?>">
        <span class="btn-inner--icon"><i class="material-icons">person_search</i></span><br>
        <span class="btn-inner--text"><?php echo e(__('Pemonev Lapangan')); ?></span>
      </a>
      <a class="btn btn-lg btn-icon btn-3 btn-primary w-100" href="<?php echo e(Route('daftar.dpl')); ?>">
        <span class="btn-inner--icon"><i class="material-icons">supervised_user_circle</i></span><br>
        <span class="btn-inner--text"><?php echo e(__('Dosen Pendamping Lapangan')); ?></span>
      </a>
      <a class="btn btn-lg btn-icon btn-3 btn-secondary w-100" href="<?php echo e(Route('daftar.mahasiswa')); ?>">
        <span class="btn-inner--icon"><i class="material-icons">assignment_ind</i></span><br>
        <span class="btn-inner--text"><?php echo e(__('Mahasiswa')); ?></span>
      </a>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.daftar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/pendaftaran/index.blade.php ENDPATH**/ ?>