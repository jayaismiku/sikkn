

<?php $__env->startSection('title', 'Ubah Perangkat Desa'); ?>

<?php $__env->startSection('pathway'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item text-sm">
      <a class="opacity-3 text-dark" href="<?php echo e(route('home')); ?>">
        <span class="material-icons">cottage</span>
      </a>
    </li>
    <li class="breadcrumb-item text-sm">
      <a class="opacity-5 text-dark" href="<?php echo e(route('perangkat.index')); ?>"><?php echo e(__('Perangkat')); ?></a>
    </li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">
      <span><?php echo e(__('Ubah Perangkat Desa')); ?></span>
    </li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-12">
    <div class="card my-4">
      <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-secondary shadow-secondary border-radius-lg pt-4 pb-3">
          <h6 class="text-white text-capitalize ps-3"><?php echo e(__('Ubah Perangkat Desa')); ?></h6>
        </div>
      </div>
      <div class="card-body px-0 pb-2 mx-3 ">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <br />
        <?php endif; ?>
        <form id="" method="post" action="<?php echo e(route('perangkat.update', $perangkat->perangkat_id)); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group">
            <label class="form-label" for="nama_lengkap"><?php echo e(__('Nama Lengkap:')); ?></label>
            <input type="text" class="form-control px-2" name="nama_lengkap" value="<?php echo e($perangkat->nama_lengkap); ?>" required/>
          </div>
          <div class="form-group">
              <label class="form-label" for="jabatan"><?php echo e(__('Jabatan:')); ?></label>
              <select class="form-control form-select px-2" aria-label=".form-select-sm example" id="jabatan" name="jabatan" required>
                <option value="<?php echo e(__('Kepala Desa')); ?>" <?php echo e(($perangkat->jabatan=='Kepala Desa')?'selected':''); ?>><?php echo e(__('Kepala Desa')); ?></option>
                <option value="<?php echo e(__('Sekretaris Desa')); ?>" <?php echo e(($perangkat->jabatan=='Sekretaris Desa')?'selected':''); ?>><?php echo e(__('Sekretaris Desa')); ?></option>
                <option value="<?php echo e(__('Pegawai Desa')); ?>" <?php echo e(($perangkat->jabatan=='Pegawai Desa')?'selected':''); ?>><?php echo e(__('Pegawai Desa')); ?></option>
                <option value="<?php echo e(__('Kepala Dusun')); ?>" <?php echo e(($perangkat->jabatan=='Kepala Dusun')?'selected':''); ?>><?php echo e(__('Kepala Dusun')); ?></option>
                <option value="<?php echo e(__('Ketua RW')); ?>" <?php echo e(($perangkat->jabatan=='Ketua RW')?'selected':''); ?>><?php echo e(__('Ketua RW')); ?></option>
                <option value="<?php echo e(__('Ketua RT')); ?>" <?php echo e(($perangkat->jabatan=='Ketua RT')?'selected':''); ?>><?php echo e(__('Ketua RT')); ?></option>
              </select>
          </div>
          <div class="form-group">
              <label class="form-label" for="telp"><?php echo e(__('Telp:')); ?></label>
              <input type="text" class="telp form-control px-2" name="telp" value="<?php echo e($perangkat->telp); ?>" required/>
          </div>
          <div class="form-group">
              <label class="form-label" for="desa"><?php echo e(__('Desa')); ?></label>
              <select class="form-control form-select px-2" aria-label=".form-select-sm example" id="desa" name="desa" required>
                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ds->desa_id); ?> <?php echo e(($perangkat->desa_id==$ds->desa_id)?'selected':''); ?>"><?php echo e($ds->nama_desa); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
          <div class="form-group mt-4">
            <input type="hidden" class="form-control px-2 py-2" name="perangkat_id" value="<?php echo e($perangkat->perangkat_id); ?>" />
            <button type="submit" class="btn btn-success xs">
              <span class="material-icons">save</span>
            </button>
            <a class="btn btn-info xs" href="<?php echo e(route('perangkat.index')); ?>">
              <span class="material-icons">undo</span>
            </a>
          </div>         
        </form>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function(){
    $('.telp').change(function(){
      let telp = '62';
      let angka1 = $(this).val().substring(0,1);
      let angka2 = $(this).val().substring(1);
      if(angka1 == 0){
        telp = telp + angka2;
      }else{
        telp = angka1 + angka2;
      }
      $(this).val(telp);
      console.log(telp);
    });

  });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/perangkat/edit.blade.php ENDPATH**/ ?>