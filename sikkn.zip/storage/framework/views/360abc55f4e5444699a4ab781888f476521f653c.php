

<?php $__env->startSection('title', 'Verify Mahasiswa'); ?>

<?php $__env->startSection('pathway'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item text-sm">
      <a class="opacity-3 text-dark" href="<?php echo e(route('home')); ?>">
        <span class="material-icons">cottage</span>
      </a>
    </li>
    <li class="breadcrumb-item text-sm">
      <a class="opacity-5 text-dark" href="<?php echo e(route('mahasiswa.index')); ?>">Mahasiswa</a>
    </li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">
      <span>Verifikasi Mahasiswa</span>
    </li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-12">
    <div class="card my-4">
      <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-secondary shadow-secondary border-radius-lg pt-4 pb-3">
          <h6 class="text-white text-capitalize ps-3"><?php echo e(__('Verifikasi Mahasiswa')); ?></h6>
        </div>
      </div>
      <div class="card-body px-0 pb-2 mx-3 ">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <br />
        <?php endif; ?>
        <form id="editMahasiswa" method="post" action="<?php echo e(route('mahasiswa.update', $mahasiswa->mahasiswa_id)); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="nim"><?php echo e(__('NIM:')); ?></label>
            <input type="text" class="form-control form-control-sm p-2" name="nim" value="<?php echo e($mahasiswa->nim); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="nama_lengkap"><?php echo e(__('Nama Lengkap:')); ?></label>
            <input type="text" class="form-control form-control-sm p-2" name="nama_lengkap" value="<?php echo e($mahasiswa->nama_lengkap); ?>" required/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="fakultas"><?php echo e(__('Fakultas')); ?></label>
            <select class="form-control form-control-sm p-2 form-select form-select-sm" aria-label=".form-select-sm select-fakultas" name="fakultas" required>
              <option value="FST" <?php echo e($mahasiswa->fakultas=='FST'?'selected':''); ?>><?php echo e(__('Fakultas Sains dan Teknologi')); ?></option>
              <option value="FSH" <?php echo e($mahasiswa->fakultas=='FSH'?'selected':''); ?>><?php echo e(__('Fakultas Sosial Humaniora')); ?></option>
              <option value="FEB" <?php echo e($mahasiswa->fakultas=='FEB'?'selected':''); ?>><?php echo e(__('Fakultas Ekonomi dan Bisnis')); ?></option>
              <option value="FAI" <?php echo e($mahasiswa->fakultas=='FAI'?'selected':''); ?>><?php echo e(__('Fakultas Agama Islam')); ?></option>
            </select>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="prodi"><?php echo e(__('Program Studi')); ?></label>
            <select class="form-control form-control-sm p-2 form-select form-select-sm" aria-label=".form-select-sm select-prodi" name="prodi" required>
              <option value="TE" <?php echo e($mahasiswa->prodi=='TE'?'selected':''); ?>><?php echo e(__('Teknik Elektro')); ?></option>
              <option value="IF" <?php echo e($mahasiswa->prodi=='IF'?'selected':''); ?>><?php echo e(__('Teknik Informatika')); ?></option>
              <option value="TI" <?php echo e($mahasiswa->prodi=='TI'?'selected':''); ?>><?php echo e(__('Teknik Industri')); ?></option>
              <option value="TP" <?php echo e($mahasiswa->prodi=='TP'?'selected':''); ?>><?php echo e(__('Teknologi Pangan')); ?></option>
              <option value="BIOTEK" <?php echo e($mahasiswa->prodi=='BIOTEK'?'selected':''); ?>><?php echo e(__('Bioteknologi')); ?></option>
              <option value="FA" <?php echo e($mahasiswa->prodi=='FA'?'selected':''); ?>><?php echo e(__('Farmasi')); ?></option>
              <option value="AGRI" <?php echo e($mahasiswa->prodi=='AGRI'?'selected':''); ?>><?php echo e(__('Agribisnis')); ?></option>
              <option value="ILKOM" <?php echo e($mahasiswa->prodi=='ILKOM'?'selected':''); ?>><?php echo e(__('Ilmu Komunikasi')); ?></option>
              <option value="PSI" <?php echo e($mahasiswa->prodi=='PSI'?'selected':''); ?>><?php echo e(__('Psikologi')); ?></option>
              <option value="KTF" <?php echo e($mahasiswa->prodi=='KTF'?'selected':''); ?>><?php echo e(__('Kriya Tekstil dan Fashion')); ?></option>
              <option value="AP" <?php echo e($mahasiswa->prodi=='AP'?'selected':''); ?>><?php echo e(__('Administrasi Publik')); ?></option>
              <option value="AK" <?php echo e($mahasiswa->prodi=='AK'?'selected':''); ?>><?php echo e(__('Akuntansi')); ?></option>
              <option value="MAN" <?php echo e($mahasiswa->prodi=='MAN'?'selected':''); ?>><?php echo e(__('Manajemen')); ?></option>
              <option value="PAI" <?php echo e($mahasiswa->prodi=='PAI'?'selected':''); ?>><?php echo e(__('Pendidikan Agama Islam')); ?></option>
              <option value="PIAUD" <?php echo e($mahasiswa->prodi=='PIAUD'?'selected':''); ?>><?php echo e(__('Pendidikan Islam Anak Usia Dini')); ?></option>
              <option value="HKI" <?php echo e($mahasiswa->prodi=='HKI'?'selected':''); ?>><?php echo e(__('Hukum Keluarga Islam')); ?></option>
              <option value="KPI" <?php echo e($mahasiswa->prodi=='KPI'?'selected':''); ?>><?php echo e(__('Komunikasi Penyiaran Islam')); ?></option>
              <option value="EKSYAR" <?php echo e($mahasiswa->prodi=='EKSYAR'?'selected':''); ?>><?php echo e(__('Ekonomi Syariah')); ?></option>
            </select>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="semester"><?php echo e(__('Semester')); ?></label>
            <select class="form-control form-control-sm p-2 form-select form-select-sm" aria-label=".form-select-sm select-semester" name="semester" required>
              <option value="4" <?php echo e($mahasiswa->semester=='4'?'selected':''); ?>><?php echo e(__('Semester 4')); ?></option>
              <option value="6" <?php echo e($mahasiswa->semester=='6'?'selected':''); ?>><?php echo e(__('Semester 6')); ?></option>
              <option value="8" <?php echo e($mahasiswa->semester=='8'?'selected':''); ?>><?php echo e(__('Semester 8')); ?></option>
            </select>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="telp"><?php echo e(__('Telp (WA)')); ?></label>
            <div class="input-group mb-3">
              <span class="input-group-text text-sm" id="basic-addon1">+62</span>
              <input type="text" class="form-control form-control-sm" placeholder="telp" aria-label="telp" aria-describedby="basic-addon1" name="telp" value="<?php echo e($mahasiswa->telp); ?>" required>
            </div>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="alamat"><?php echo e(__('Alamat')); ?></label>
            <input type="text" class="form-control form-control-sm p-2" name="alamat" value="<?php echo e($mahasiswa->alamat); ?>"/>
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="krs"><?php echo e(__('Bukti KRS')); ?></label>
            <img class="img img-fluid img-thumbnail" src="<?php echo e(asset('storage/app/'.$mahasiswa->unggah_krs)); ?>" alt="Unggah KRS" title="Unggah KRS">
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="bayar"><?php echo e(__('Bukti Bayar KKN')); ?></label>
            <img class="img img-fluid img-thumbnail" src="<?php echo e(asset('storage/app/'.$mahasiswa->unggah_keuangan)); ?>" alt="Unggah KRS" title="Unggah KRS">
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="ukt"><?php echo e(__('Bukti Bayar UKT')); ?></label>
            <img class="img img-fluid img-thumbnail" src="<?php echo e(asset('storage/app/'.$mahasiswa->unggah_ukt)); ?>" alt="Unggah KRS" title="Unggah KRS">
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="sakit"><?php echo e(__('Surat Sakit (Berat)')); ?></label>
            <img class="img img-fluid img-thumbnail" src="<?php echo e(asset('storage/app/'.$mahasiswa->sakit_berat)); ?>" alt="Unggah KRS" title="Unggah KRS">
          </div>
          <div class=" input-group-outline my-3">
            <label class="form-label" for="alergi"><?php echo e(__('Alergi:')); ?></label>
            <input type="text" class="form-control form-control-sm p-2" name="alergi" value="<?php echo e($mahasiswa->alergi); ?>"/>
          </div>
          <div class="form-group">
            <input type="hidden" class="form-control px-2 py-2" name="mahasiswa_id" value="<?php echo e($mahasiswa->mahasiswa_id); ?>" />
            <button type="submit" class="btn btn-success xs">
              <span class="material-icons">save</span>
            </button>
            <a class="btn btn-info xs" href="<?php echo e(route('mahasiswa.index')); ?>">
              <span class="material-icons">undo</span>
            </a>
            <a class="btn btn-warning xs" href="<?php echo e(route('mahasiswa.verify', $mahasiswa->user_id)); ?>" onclick="event.preventDefault(); document.getElementById('verify-account').submit();">
              <span class="material-icons">verified</span>
            </a>
          </div>         
        </form>
        <form id="verify-account" action="<?php echo e(route('mahasiswa.verified', $mahasiswa->user_id)); ?>" method="POST" class="d-none">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/mahasiswa/verify.blade.php ENDPATH**/ ?>