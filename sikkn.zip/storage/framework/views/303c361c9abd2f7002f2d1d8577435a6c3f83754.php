

<?php $__env->startSection('title', 'Tambah Logbook'); ?>

<?php $__env->startSection('pathway'); ?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
    <li class="breadcrumb-item text-sm">
      <a class="opacity-3 text-dark" href="<?php echo e(route('home')); ?>">
        <span class="material-icons">cottage</span>
      </a>
    </li>
    <li class="breadcrumb-item text-sm">
      <a class="opacity-5 text-dark" href="<?php echo e(route('logbook.index')); ?>"><?php echo e(__('Logbook')); ?></a>
    </li>
    <li class="breadcrumb-item text-sm text-dark active" aria-current="page">
      <span><?php echo e(__('Tambah Logbook')); ?></span>
    </li>
  </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-12">
    <div class="card my-4">
      <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
        <div class="bg-gradient-secondary shadow-secondary border-radius-lg pt-4 pb-3">
          <h6 class="text-white text-capitalize ps-3">Tambah Logbook</h6>
        </div>
      </div>
      <div class="card-body px-0 pb-2 mx-3 ">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <br />
        <?php endif; ?>
        <form id="tambah-logbook" method="post" action="<?php echo e(route('logbook.store')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label class="form-label" for="nama_kegiatan"><?php echo e(__('Nama Kegiatan:')); ?></label>
            <input type="text" class="form-control px-2" id="nama_kegiatan" name="nama_kegiatan"/>
          </div>
          <div class="form-group">
              <label class="form-label" for="tanggal_kegiatan"><?php echo e(__('Tanggal Kegiatan:')); ?></label>
              <input type="datetime-local" class="form-control px-2" id="tanggal_kegiatan" name="tanggal_kegiatan"/>
          </div>
          <div class="form-group">
              <label class="form-label" for="deskripsi_kegiatan"><?php echo e(__('Deskripsi Kegiatan:')); ?></label>
              <textarea id="deskripsi-kegiatan" class="form-control px-2" name="deskripsi_kegiatan" rows="4"></textarea>
          </div>
          <div class="form-group">
              <label class="form-label" for="foto_kegiatan"><?php echo e(__('Foto Kegiatan')); ?></label>
              <input type="file" class="form-control px-2" accept="image/*" name="foto_kegiatan"/>
          </div>
          <div class="form-group mt-4">
            <input type="hidden" name="nim" value="<?php echo e($nim); ?>">
            <input type="hidden" id="slug_kegiatan" name="slug_kegiatan" value="">
            <button type="submit" class="btn btn-success xs">
              <span class="material-icons">save</span>
            </button>
            <a class="btn btn-info xs" href="<?php echo e(route('logbook.index')); ?>">
              <span class="material-icons">undo</span>
            </a>
          </div>         
        </form>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function () {
  $('#deskripsi-kegiatan').summernote();
  $('#nama_kegiatan').change(function (e) { 
    let slug = $(this).val().toLowerCase().replace(/[^a-zA-Z0-9]+/g, '-');
    $('#slug_kegiatan').val(slug);
    console.log(slug)
  });
});
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\7.4.33\htdocs\kkn7\sikkn\resources\views/logbook/create.blade.php ENDPATH**/ ?>